README File

To run this application, there are a few options:
1) Download the supplied .zip file and run locally in a Python Virtual Environment
2) Clone from Github repository [here](https://github.com/kylegraupe/PukobanSolverHW1)

From the main.py file, simply uncomment the algorithm that you would like to run with the associated input text file 
in the execute_application() function.

In the current version, this application struggles to find solutions to complex
Pukoban game grids, but will be updated in future iterations. The application is able to find
solutions to simple game grids only. 